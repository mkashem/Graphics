#pragma once
#include <stdio.h>
#include <GL/glew.h>

void createPyramid();
void renderPyramid();

extern	unsigned int pyramidvao;

