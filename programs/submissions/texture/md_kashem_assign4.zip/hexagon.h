#pragma once
#include <stdio.h>
#include <GL/glew.h>

void createHexagon();
void renderHexagon();
extern	unsigned  hexagon_vao;
