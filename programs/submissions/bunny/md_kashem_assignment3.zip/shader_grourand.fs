#version 430



in vec4 color;
out vec4 fcolor;



void main(void)
{
fcolor = color;

}


