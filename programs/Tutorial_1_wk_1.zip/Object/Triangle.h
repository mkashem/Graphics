#include <stdio.h>
#include <GL/glew.h>



extern unsigned int tri_vao;


void createTriangle();
void renderTriangle();


