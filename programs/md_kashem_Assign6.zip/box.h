#pragma once
#include <stdio.h>
#include <GL/glew.h>

void createBox();
void renderBox();

extern	unsigned int Boxvao;


