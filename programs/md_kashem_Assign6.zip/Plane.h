#include <stdio.h>
#include <GL/glew.h>

void createPlane();
void renderPlane();

extern	unsigned int vao;

