#pragma once
#include <stdio.h>
#include <GL/glew.h>

void createFan();
void renderFan();

extern	unsigned int fan_vao;